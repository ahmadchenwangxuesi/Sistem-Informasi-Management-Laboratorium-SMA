# SIML
Sistem Informasi Management Laboratorium SMA N 1 Lubuk Sikaping.

Type User : 
-Admin
-Guru
-Siswa

![1](https://cloud.githubusercontent.com/assets/12929878/9202617/eeb7d01c-407c-11e5-9b95-be6a0ce1c92d.jpg)
![2](https://cloud.githubusercontent.com/assets/12929878/9202618/eebe1a80-407c-11e5-892a-640de5e0516e.jpg)
![3](https://cloud.githubusercontent.com/assets/12929878/9202619/eec2b4f0-407c-11e5-80d5-d6995b641638.jpg)
![4](https://cloud.githubusercontent.com/assets/12929878/9202620/eedd1a5c-407c-11e5-88f0-a0bcf56ba99f.jpg)
![5](https://cloud.githubusercontent.com/assets/12929878/9202614/eea2f656-407c-11e5-87b4-c854d3c9045e.jpg)
![6](https://cloud.githubusercontent.com/assets/12929878/9202615/eea8c928-407c-11e5-8ac4-35baddb9bdf2.jpg)
![7](https://cloud.githubusercontent.com/assets/12929878/9202616/eeb14af8-407c-11e5-85cd-12a9e87e0645.jpg)
