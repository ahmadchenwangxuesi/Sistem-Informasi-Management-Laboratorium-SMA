<?php
	mysql_connect("localhost","root","")or die("Gagal Koneksi");
	mysql_select_db("")or die("Tidak ada Database");
?>
